tests_ezdna_custom currently requires connection to a private test server.
I do have plans to create instructions for creating your own test server,
and ensuring that these tests match that test server, but that will be
sometime in the future.